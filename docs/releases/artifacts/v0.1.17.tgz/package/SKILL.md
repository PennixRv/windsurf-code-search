---
name: pennix-windsurf-code-search
description: 为含义和范围明确、但没有有效代码锚点的业务、历史或旧代码定位发现有界语义候选；有锚点先精确文本或 CodeGraph。不因自然语言表述自动触发，不负责结构影响分析。
metadata:
  short-description: 按需获取语义代码候选
---
# Windsurf Code Search

Windsurf Code Search 当前由外部模型规划有界本地文本搜索、文件读取与目录发现，返回不受信任的位置候选；它不维护 CodeGraph 式持久符号关系图，不证明全量影响范围或比其他工具更快。限定目录信息、工具结果和源码片段会发送到外部端点，既有允许范围、deny 和预算仍有效。CLI 是安全边界：提示词不会创建注册、批准或白名单状态。不要添加 Windsurf 自有的 MCP 服务器、Hook、插件、项目注册、批准状态或持久化搜索服务；Context Mode 可承载真实 CLI，并按来源合同处理和索引候选。

## 路由

1. 有路径、文件名、字面量、配置或日志线索时，先在 Context Mode 内精确读取／匹配；“本地工具”不等于原生 shell。
2. 有符号／模块线索，需要调用者、被调用者、结构、关系或影响分析时，优先已批准且可用的 CodeGraph。
3. 定位含义、目标和允许范围已明确但没有有效代码锚点时，可直接使用本 Skill，不强制先做 rg／图探测。只知道项目范围不算代码锚点；含义或范围仍不清楚时先澄清。
4. 有锚点的本地证据已核验仍不能定位时，先看是否还有可用锚点；没有且仍需语义候选才进入本 Skill。一次图未命中不触发机械外部后备。

不要仅因请求使用自然语言就触发本 Skill，不自动并行运行 CodeGraph 和 Windsurf。已有足够本地证据、精确文本匹配、外部文档、普通对话和单纯影响分析均跳过；图缺失或受限不授权外送影响分析。完整跨组件判定见 `$pennix-workflow-routing`。

## 调用

调用前读取 [references/script-contract.md](references/script-contract.md)，核对参数、凭据访问、资源限制和结果覆盖范围。普通调用使用 Pennix 集合提供的受管 PATH 命令；链接安装与冲突处理由 `$pennix-component-lifecycle` 负责，本 Skill 不创建链接。

提供一个已存在的明确项目目录和一个有范围的自然语言查询：

真实非交互 CLI 默认由 Context Mode 执行；保留 cwd、退出码和完整结构化回执，不模拟 MCP 或自行读取凭据。

```bash
windsurf-code-search \
  --project "/absolute/path/to/project" \
  --query "Where is the legacy import flow implemented?"
```

唯一可选控制项是有范围的 `--max-results`、可重复且只能相加的相对 `--deny` 模式和 `--no-external`。命令先接受明确的 `WINDSURF_API_KEY`。仅 Linux 或 WSL 下，缺少明确密钥时才可以通过包所有者提供的、有范围的无 Shell 辅助程序使用当前用户的 Devin CLI 登录。辅助程序固定凭据路径，拒绝符号链接、超大文件、未知字段和不支持值，不扫描桌面状态。

所有者配置路径可通过 `configure` 和 `config-doctor` 使用；它是私有、原子和脱敏的。运行时优先级是明确环境变量、所有者配置、Devin 登录。命令不输出密钥、不持久化提示词或响应，也不输出远程原始错误。不要把凭据复制到所有者配置命令之外的文件、命令历史、日志或提交。调用方必须阻止所有凭据访问和远程搜索时使用 `--no-external`。

`status`、`truncated` 和 `coverage` 描述本次限定范围的结果完整性。`complete` 不代表覆盖不受限制的整个仓库，也不证明语义正确；`truncated` 的访问计数、原因和可用前沿须保留，不能将不完整的无匹配结果当作全仓无结果。

使用结果前，将相对路径解析到同一项目根目录内，默认在 Context Mode 内核验当前源码的路径、行范围和语义；`local_range_validated` 只说明本地路径／范围有效，不证明语义命中。需要关系分析时，用 CodeGraph 扩展已核验候选。输出永远只是候选，可以按来源合同处理或索引，须保留来源及“未核验”状态；不能直接写成 Trellis 或 CodeGraph 事实，索引命中不代表核验。搜索与凭据操作遵守真实 CLI 和认证 owner，认证值不能作为普通分析输入。网络失败或格式错误是封闭的 `FC_*` 诊断，保留首个失败并报告缺口，不反复换词、换 provider 或扩大范围直到通过。
